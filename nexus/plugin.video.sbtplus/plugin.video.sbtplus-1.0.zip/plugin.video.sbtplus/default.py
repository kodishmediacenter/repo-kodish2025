import sys
import xbmcplugin
import xbmcgui
import xbmc
import urllib.parse
import subprocess
import os
import xbmcvfs
import webbrowser
import platform

# Handle do plugin e argumentos da URL
addon_handle = int(sys.argv[1])
base_url = sys.argv[0]
args = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))

# Caminho da pasta de ícones
def caminho_icone(nome_arquivo):
    return os.path.join(xbmcvfs.translatePath("special://home/addons/plugin.video.sbtplus/resources/media/"), nome_arquivo)

def abrir_como_app(url):
    sistema = platform.system()

    try:
        if sistema == "Windows":
            # Caminhos possíveis do Chrome
            caminhos = [
                r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
            ]

            chrome_path = None
            for caminho in caminhos:
                if os.path.exists(caminho):
                    chrome_path = caminho
                    break

            if chrome_path:
                subprocess.Popen([chrome_path, f'--app={url}'])
                xbmcgui.Dialog().notification("Abrindo","Site aberto no Chrome (Windows)",xbmcgui.NOTIFICATION_INFO,3000)
                return
            else:
                xbmcgui.Dialog().notification("Aviso","Chrome não encontrado, abrindo no navegador padrão",xbmcgui.NOTIFICATION_INFO,3000)
                webbrowser.open(url)
                return

        elif sistema == "Linux":
            chrome_flatpak = "com.google.Chrome"
            chromium_flatpak = "org.chromium.Chromium"

            if shutil.which("flatpak"):
                try:
                    subprocess.Popen(["flatpak", "run", chrome_flatpak, f"--app={url}"])
                    xbmcgui.Dialog().notification("Abrindo","Site aberto no Chrome (Flatpak)",xbmcgui.NOTIFICATION_INFO,3000)
                    return
                except Exception:
                    pass

                try:
                    subprocess.Popen(["flatpak", "run", chromium_flatpak, f"--app={url}"])
                    xbmcgui.Dialog().notification("Abrindo","Site aberto no Chromium (Flatpak)",xbmcgui.NOTIFICATION_INFO,3000)
                    return
                except Exception:
                    pass

            xbmcgui.Dialog().notification(
                "Aviso",
                "Nenhum Chrome/Chromium Flatpak encontrado, abrindo no navegador padrão",
                xbmcgui.NOTIFICATION_INFO,
                3000
            )
            webbrowser.open(url)
            return

        else:
            # Caso seja macOS ou outro sistema
            xbmcgui.Dialog().notification(
                "Aviso",
                f"Sistema {sistema} não suportado, abrindo no navegador padrão",
                xbmcgui.NOTIFICATION_INFO,
                3000
            )
            webbrowser.open(url)

    except Exception as e:
        xbmcgui.Dialog().notification(
            "Erro",
            f"Falha ao abrir: {str(e)}",
            xbmcgui.NOTIFICATION_ERROR,
            3000
        )

# Adiciona item ao menu com ícone
def adicionar_item(nome, query=None, icon=None):
    url = f"{base_url}?{urllib.parse.urlencode(query)}" if query else base_url
    item = xbmcgui.ListItem(label=nome)
    if icon:
        icone_path = caminho_icone(icon)
        item.setArt({'icon': icone_path, 'thumb': icone_path})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=item, isFolder=True)

# Funções de cada sessão
def menu_principal():
    adicionar_item(" Buscar Conteudo", {"action": "buscar"}, "buscar.png")
    adicionar_item(" Novelas", {"action": "novelas"}, "novelas.png")
    adicionar_item(" Series", {"action": "series"}, "series.png")
    adicionar_item(" Programas de TV", {"action": "programas"}, "ptv.png")
    adicionar_item(" Infantil", {"action": "kids"}, "kids.png")
    xbmcplugin.endOfDirectory(addon_handle)

def buscar():
    termo = xbmcgui.Dialog().input("Buscar no SBT Plus", type=xbmcgui.INPUT_ALPHANUM)
    if termo:
        query = urllib.parse.quote_plus(termo)
        url = f"https://mais.sbt.com.br/search?q={query}"
        abrir_como_app(url)

def novelas():
    abrir_como_app("https://mais.sbt.com.br/catalog/novelas")
def series():
    abrir_como_app("https://mais.sbt.com.br/catalog/series")
def programas(): 
    abrir_como_app("https://mais.sbt.com.br/catalog/programas")
def kids():
    abrir_como_app("https://mais.sbt.com.br/kids")



# Roteamento das ações
if not args:
    menu_principal()
else:
    action = args.get("action")
    if action == "buscar":
        buscar()
    elif action == "novelas":
        novelas()
    elif action == "series":
        series()
    elif action == "programas":
        programas()
    elif action == "kids":
        kids()
