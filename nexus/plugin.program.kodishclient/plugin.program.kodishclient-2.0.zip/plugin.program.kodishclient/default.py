# -*- coding: utf-8 -*-
import xbmcgui,xbmc
import platform
import sys
import os

sistema = platform.system()

def fontes_addons(): 
    deffontes = xbmcvfs.translatePath("special://home/addons/plugin.program.kodishclient/conf/sources.xml")
    destino = xbmcvfs.translatePath("special://home/userdata/sources.xml")
    
    with open(deffontes, 'r', encoding='utf-8') as arquivo_origem:
        conteudo = arquivo_origem.read()

    # Abre um novo arquivo para escrita e grava o conteúdo lido do arquivo sources.xml
    with open(destino, 'w', encoding='utf-8') as arquivo_destino:
        arquivo_destino.write(conteudo)
        xbmcgui.Dialog().ok('[B][COLOR white]AVISO[/COLOR][/B]','Sucesso !!! Para Surtir Efeito e necessario sair do Kodi e Abrir novamente') 


def main():
    dialog = xbmcgui.Dialog()
    xbmcgui.Dialog().ok('[B][COLOR white]AVISO[/COLOR][/B]','Esse Script apaga sua fontes Atuais para continuar prescione Sim na proxima Janela') 
    link = dialog.select('[B][COLOR white]Instalar as Fontes da Kodish em Seu Kodi [/COLOR][/B] : ', ['Sim','Não'])

    if link == 0:
        fontes_addons()
    if link == 1:
        main()
 


main()
