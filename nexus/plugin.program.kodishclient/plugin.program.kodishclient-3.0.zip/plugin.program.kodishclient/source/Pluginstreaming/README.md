DOWNLOAD DO ARQUIVO

Instruções para a adição no gestor:

Ir para o Kodi gestor de ficheiros.

Clicar em "Adicionar fonte"

O endereço para a fonte é https://freeddons.github.io/Repo-FREEDDONS (Dar o nome de "Pluginstreaming").

Ir para "Addons"

Em Addons, instalar de um ficheiro zip. Quando perguntar pela localização, selecionar "Pluginstreaming", e instalar Pluginstreaming.zip
Repositório Instalado!!

AVISO: POR FAVOR,SE VOCE ESTA LENDO ESTA MENSAGEM NÃO ESPALHE O CODIGO FONTE DO ADDON,TENHA BOM SENSO E NÃO ESTRAGUE A EXPERIENCIA DOS OUTROS USUARIOS!

