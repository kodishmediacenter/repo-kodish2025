import sys
import os
import base64
import hashlib
import hmac
import xbmcaddon
import xbmc

def derive_secret():
    addon = xbmcaddon.Addon()
    addon_id = addon.getAddonInfo('id')
    salt = '2025XAI'
    return hashlib.sha256((addon_id + salt).encode('utf-8')).hexdigest()

def load_encrypted_code():
    addon_path = os.path.dirname(os.path.abspath(__file__))
    encrypted_code_path = os.path.join(addon_path, "core_encrypted.bin")

    if not os.path.exists(encrypted_code_path):
        raise FileNotFoundError("Arquivo criptografado não encontrado.")

    with open(encrypted_code_path, "r") as f:
        base64_combined = f.read()

    combined = base64.b64decode(base64_combined)
    received_hmac = combined[:32]
    encrypted = combined[32:]

    secret = derive_secret()
    calculated_hmac = hmac.new(
        secret.encode('utf-8'),
        encrypted,
        hashlib.sha256
    ).digest()

    if not hmac.compare_digest(received_hmac, calculated_hmac):
        raise ValueError("Falha na verificação de integridade do arquivo criptografado.")

    key = hashlib.sha256(secret.encode('utf-8')).digest()
    decrypted_bytes = bytearray(
        encrypted[i] ^ key[i % len(key)] for i in range(len(encrypted))
    )

    return decrypted_bytes.decode('utf-8')

def main():
    try:
        code = load_encrypted_code()
        exec(code, globals())
    except Exception as e:
        xbmc.log(f"Erro ao executar o código descriptografado: {str(e)}", xbmc.LOGERROR)
        raise

if __name__ == "__main__":
    main()
