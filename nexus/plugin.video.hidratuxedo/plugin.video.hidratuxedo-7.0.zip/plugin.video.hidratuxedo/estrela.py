import xbmc
import xbmcgui

def web_browser(urlcn):
        import webbrowser
        if xbmc . getCondVisibility ( 'system.platform.android' ) :
                ost = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( ''+urlcn+'' ) )
        else:
                ost = webbrowser . open ( ''+urlcn+'' )







def conect():
    dialog = xbmcgui.Dialog()
    player = dialog.select('Hidra Tuxedo', ['Casa 1','Casa 2','Cozinha','Piscina','Casa Dinamica','Banheiro'])

    if player == 0:
            url = "https://embedmax.site/tvl/estrelacasa1.php"
            web_browser(url)

    if player == 1:
            url = "https://embedmax.site/tvl/estrelacasa2.php"
            web_browser(url)

    if player == 2:
            url = "https://embedmax.site/tvl/estrelacasacozinha.php"
            web_browser(url)

    if player == 3:
            url = "https://embedmax.site/tvl/estrelacasapiscina.php"
            web_browser(url)

    if player == 4:
            url = "https://embedmax.site/tvl/estrelacasadinamica.php"
            web_browser(url)

    if player == 5:
            url = "https://embedmax.site/tvl/estrelacasabanheiro.php"
            web_browser(url)
